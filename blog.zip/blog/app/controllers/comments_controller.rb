class CommentsController < ApplicationController
http_basic_authenticate_with name: "lavs", password: "lavs", only: :destroy
def create
    @articles = Article.find(params[:article_id])
    @comment = @articles.comments.create(comment_params)
    redirect_to article_path(@articles)
  end

def destroy
    @articles = Article.find(params[:article_id])
    @comment = @articles.comments.find(params[:id])
    @comment.destroy
    redirect_to article_path(@articles)
  end
  
  private
    def comment_params
      params.require(:comment).permit(:commenter, :body)
    end
end
